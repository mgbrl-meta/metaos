const BASE_URL = process.env.METAOS_BASE_URL || "https://metaos-seven.vercel.app";
const TARGET = (process.env.TARGET_AD || "yogita28").toLowerCase();

function n(v) {
  if (v === null || v === undefined || v === "") return 0;
  const x = Number(
    String(v)
      .replace(/,/g, "")
      .replace(/₹/g, "")
      .replace(/%/g, "")
      .trim()
  );
  return Number.isFinite(x) ? x : 0;
}

function dateKey(row) {
  const raw =
    row.date ??
    row.day ??
    row.Date ??
    row.Day ??
    row["Date"] ??
    row["Day"] ??
    row["Reporting starts"] ??
    row["Reporting Starts"] ??
    "";

  if (!raw) return "";

  const s = String(raw).trim();

  const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;

  const slash = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (slash) {
    const first = Number(slash[1]);
    const second = Number(slash[2]);
    const year = Number(slash[3]);

    const day = first > 12 ? first : second > 12 ? second : first;
    const month = first > 12 ? second : second > 12 ? first : second;

    return new Date(Date.UTC(year, month - 1, day)).toISOString().slice(0, 10);
  }

  const d = new Date(s);
  if (!Number.isNaN(d.getTime())) {
    return new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()))
      .toISOString()
      .slice(0, 10);
  }

  return "";
}

function adName(row) {
  return String(
    row.adName ??
      row.ad_name ??
      row["ad name"] ??
      row["Ad name"] ??
      row["Ad Name"] ??
      ""
  );
}

function adId(row) {
  return String(row.adId ?? row.ad_id ?? row["ad id"] ?? row["Ad ID"] ?? adName(row));
}

function campaignName(row) {
  return String(row.campaignName ?? row.campaign_name ?? row["campaign name"] ?? row["Campaign name"] ?? "");
}

function spend(row) {
  return n(
    row.spend ??
      row.amountSpent ??
      row.amount_spent ??
      row["amount spent inr"] ??
      row["Amount spent (INR)"] ??
      row["Amount spent"]
  );
}

function purchases(row) {
  return n(row.purchases ?? row.Purchases ?? row.results ?? row.Results);
}

function purchaseValue(row) {
  return n(
    row.revenue ??
      row.purchaseValue ??
      row.purchase_value ??
      row.conversionValue ??
      row.conversion_value ??
      row["purchases conversion value"] ??
      row["Purchases conversion value"] ??
      row["Purchase conversion value"] ??
      row["Purchase Conversion Value"]
  );
}

function metaAovField(row) {
  return n(row.aov ?? row.AOV ?? row["aov"] ?? row["AOV"]);
}

function costPerResultField(row) {
  return n(
    row.costPerResult ??
      row.cost_per_result ??
      row["cost per result"] ??
      row["Cost per result"]
  );
}

function gptField(row) {
  return n(
    row.gpt ??
      row.GPT ??
      row["gpt"] ??
      row["GPT"] ??
      row["Gross Profit Per Transaction"] ??
      row["gross profit per transaction"]
  );
}

function summarize(rows) {
  const s = rows.reduce((sum, r) => sum + spend(r), 0);
  const p = rows.reduce((sum, r) => sum + purchases(r), 0);
  const v = rows.reduce((sum, r) => sum + purchaseValue(r), 0);

  const aov = p > 0 ? v / p : 0;
  const cpa = p > 0 ? s / p : 0;
  const gpt = p > 0 ? aov - cpa : 0;
  const roas = s > 0 ? v / s : 0;

  return { spend: s, purchases: p, purchaseValue: v, aov, cpa, gpt, roas };
}

function latestDate(rows) {
  return [...new Set(rows.map(dateKey).filter(Boolean))].sort().at(-1) || "";
}

function zeroPurchaseItems(rows, threshold) {
  const latest = latestDate(rows);

  const latestSpendAdIds = new Set(
    rows
      .filter((r) => dateKey(r) === latest)
      .filter((r) => spend(r) > 0)
      .map(adId)
      .filter(Boolean)
  );

  const grouped = new Map();

  for (const row of rows) {
    const key = adId(row);
    if (!latestSpendAdIds.has(key)) continue;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(row);
  }

  const items = [];

  for (const [key, adRows] of grouped.entries()) {
    const latestRows = adRows.filter((r) => dateKey(r) === latest);
    const life = summarize(adRows);
    const y = summarize(latestRows);
    const sample = latestRows[0] || adRows[0];

    if (y.spend > 0 && life.spend >= threshold && life.purchases === 0) {
      items.push({
        key,
        ad: adName(sample),
        campaign: campaignName(sample),
        lifeSpend: life.spend,
        latestSpend: y.spend,
        purchases: life.purchases,
      });
    }
  }

  return { latest, items: items.sort((a, b) => b.lifeSpend - a.lifeSpend) };
}

async function fetchJson(path) {
  const url = `${BASE_URL}${path}${path.includes("?") ? "&" : "?"}t=${Date.now()}`;
  const started = Date.now();
  const res = await fetch(url, {
    cache: "no-store",
    headers: {
      "Cache-Control": "no-cache",
      "Pragma": "no-cache",
    },
  });

  const ms = Date.now() - started;
  const json = await res.json().catch(() => ({}));

  return { url, status: res.status, ms, json };
}

function printMoney(x) {
  return `₹${Math.round(x).toLocaleString("en-IN")}`;
}

console.log("===== MetaOS QC =====");
console.log("BASE_URL:", BASE_URL);
console.log("TARGET_AD:", TARGET);
console.log("");

const sheet = await fetchJson("/api/meta-sheet?source=raw");
const rows = sheet.json.rows || sheet.json.data || [];

console.log("===== 1) meta-sheet source QC =====");
console.log({
  status: sheet.status,
  ms: sheet.ms,
  source: sheet.json.source,
  sheetTab: sheet.json.sheetTab,
  rowCountFromApi: sheet.json.rowCount,
  actualRowsReturned: rows.length,
  latestDateFromApi: sheet.json.latestDate,
  latestDateComputed: latestDate(rows),
  generatedAt: sheet.json.generatedAt,
});

console.log("");

console.log("===== 2) Zero Purchase offline recompute from meta-sheet =====");
for (const threshold of [2000, 3000, 5000]) {
  const z = zeroPurchaseItems(rows, threshold);
  console.log(`Threshold ${printMoney(threshold)}`);
  console.log({
    latest: z.latest,
    count: z.items.length,
    lifetimeWaste: Math.round(z.items.reduce((s, x) => s + x.lifeSpend, 0)),
    latestDayWaste: Math.round(z.items.reduce((s, x) => s + x.latestSpend, 0)),
  });

  z.items.slice(0, 5).forEach((x, i) => {
    console.log(`  ${i + 1}. ${printMoney(x.lifeSpend)} | Latest ${printMoney(x.latestSpend)} | ${x.ad}`);
  });
}

console.log("");

console.log("===== 3) Dedicated zero-purchase API timing =====");
const zeroApi = await fetchJson("/api/meta-zero-purchase");
console.log({
  status: zeroApi.status,
  ms: zeroApi.ms,
  source: zeroApi.json.source,
  sheetTab: zeroApi.json.sheetTab,
  rowCount: zeroApi.json.rowCount,
  latest: zeroApi.json.latest,
  latestRowCount: zeroApi.json.latestRowCount,
  latestSpendAdCount: zeroApi.json.latestSpendAdCount,
  itemCountBeforeThreshold: Array.isArray(zeroApi.json.items) ? zeroApi.json.items.length : 0,
  error: zeroApi.json.error || "",
});

console.log("");

console.log("===== 4) GPT target-ad QC =====");
const targetRows = rows.filter((r) => adName(r).toLowerCase().includes(TARGET));

console.log({
  matchedRows: targetRows.length,
  targetLatest: latestDate(targetRows),
});

if (!targetRows.length) {
  console.log("No target rows found. Set TARGET_AD='exact name or handle' and rerun.");
} else {
  const byAd = new Map();

  for (const row of targetRows) {
    const key = adId(row);
    if (!byAd.has(key)) byAd.set(key, []);
    byAd.get(key).push(row);
  }

  for (const [key, adRows] of byAd.entries()) {
    const sample = adRows.at(-1);
    const life = summarize(adRows);
    const latest = latestDate(adRows);
    const latestRows = adRows.filter((r) => dateKey(r) === latest);
    const latestSummary = summarize(latestRows);

    console.log("");
    console.log("Ad:", adName(sample));
    console.log("Ad ID:", key);
    console.log("Latest:", latest);
    console.log("Campaign:", campaignName(sample));

    console.table(
      latestRows.map((r) => ({
        date: dateKey(r),
        spend: spend(r),
        purchases: purchases(r),
        purchaseValue: purchaseValue(r),
        computedAOV: purchases(r) > 0 ? purchaseValue(r) / purchases(r) : 0,
        computedCPA: purchases(r) > 0 ? spend(r) / purchases(r) : 0,
        computedGPT: purchases(r) > 0 ? purchaseValue(r) / purchases(r) - spend(r) / purchases(r) : 0,
        rowAOVField: metaAovField(r),
        rowCostPerResultField: costPerResultField(r),
        rowGPTField: gptField(r),
      }))
    );

    console.log("Lifetime computed:");
    console.log({
      spend: life.spend,
      purchases: life.purchases,
      purchaseValue: life.purchaseValue,
      aov: life.aov,
      cpa: life.cpa,
      gpt: life.gpt,
      roas: life.roas,
    });

    console.log("Latest-day computed:");
    console.log({
      spend: latestSummary.spend,
      purchases: latestSummary.purchases,
      purchaseValue: latestSummary.purchaseValue,
      aov: latestSummary.aov,
      cpa: latestSummary.cpa,
      gpt: latestSummary.gpt,
      roas: latestSummary.roas,
    });
  }
}

console.log("");
console.log("===== 5) Source-code GPT formula search =====");
console.log("Run this next:");
console.log(`grep -Rni "gpt\\|gross\\|aov\\|costPerResult\\|purchaseValue\\|purchase_value\\|cpa" components/meta/GptTab.tsx lib app store | head -260`);
